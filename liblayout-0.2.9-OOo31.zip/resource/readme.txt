iso-15924: Mapping of known script names
Blocks:    From Unicode.org: List of known block names
Scripts:   From Unicode.org: List of scripts.
